import time
import base64
import openai
import requests
import streamlit as st


# Azure OpenAI Configuración
openai.api_type = "azure"
openai.api_base = "your-deployment-endpoint" # cambiar por tu deployment endpoint
openai.api_version = "2023-03-15-preview"
openai.api_key = "your-azure-api-key" # cambiar por tu azure api key

# Ex-Human API-Key
API_KEY = "***" # Cambiar por tu ex.human api key


# Preguntar a GPT
def ask_gpt(question: str, history: str) -> str:
    """
    Obtiene respuesta en base a pregunta y contezto
    """
    quest=  {"role": "user", "content": f'{question}'}

    model_engine = "gpt-35-turbo" # Cambiar a tu deployment name ********
    
    messages = [
      {"role": "system", "content": "Your name is America. You are a helpful virtual assistant. You can answer any question. Respond to answers in a single line. Answers should be as short as possible"},
      ]
 
    prompt = messages + history
    prompt.append(quest)

    response = openai.ChatCompletion.create(
      engine=model_engine,
      messages=prompt,
      max_tokens=600,
      temperature=0.9
      )
    
    answer = response.choices[0]['message']['content']

    print(answer)

    return answer


# Leer video como bytes
def convert_video_to_bytes(video_path: str):
    """
    Converts video to bytes.
    """

    video_file = open(video_path, "rb").read()
    video_bytes = base64.b64encode(video_file).decode("utf-8")
    
    return video_bytes


# Generar el video con ex-human
def generate_video(texto: str, key: str) -> str:
    """
    Convierte Texto a Video Bytes.
    """
    # Payload
    body = {
      'bot_name': 'your-bot-name', # Cambiar por tu talking head bot
      'bot_response': texto,
      'voice_name': "Fay",
      'animation_pipeline': "high_speed",
      'idle_url': 'your-idle-url' # Cambiar por tu idle url
    }
    
    # Mandando el request para convertir texto a video.
    endpoint = "https://api.exh.ai/animations/v1/generate_lipsync"
    headers = {"Authorization": f"Bearer {key}"}
    res = requests.post(endpoint, json=body, headers=headers)
    
    return res.content

# Guardar video generado con Ex-Human
def save_video(video_bytes: str, filename: str) -> None:
    """
    Guarda video bytes dentro de archivo de video.
    """
    with open(filename, "wb") as fh:
      fh.write(video_bytes)


# body de la app

st.subheader("America - Virtual Assistant")

# Video inactivo
bytes = convert_video_to_bytes("constanza.mp4") #Your idle video
content = st.markdown(f"""
    <div id="video-container">
        <video width="320" height="240" autoplay muted loop>
            <source src="data:video/mp4;base64,{bytes}" type="video/mp4">
        </video>
    </div>
""", unsafe_allow_html=True)

# Box para input
user_input = st.text_input("Usuario: ",placeholder = "Pregunta lo que necesites ...", key="input")

# Boton de preguntar
pregunta = st.button("Preguntar", type="primary")
if pregunta:
    result = ask_gpt(user_input, []) 
    video_content = generate_video(result, API_KEY)
    save_video(video_content, "lipsync_video.mp4")
    bytes = convert_video_to_bytes("lipsync_video.mp4")
    content.empty()
    content.markdown(f"""
    <video width="320" height="240" autoplay>
        <source src="data:video/mp4;base64,{bytes}" type="video/mp4">
    </video>
    """, unsafe_allow_html=True)
    time.sleep(3)

    content.empty()
    bytes = convert_video_to_bytes("constanza.mp4") # your idle video
    content.markdown(f"""
        <div id="video-container">
            <video width="320" height="240" autoplay muted loop>
                <source src="data:video/mp4;base64,{bytes}" type="video/mp4">
            </video>
        </div>
    """, unsafe_allow_html=True)

